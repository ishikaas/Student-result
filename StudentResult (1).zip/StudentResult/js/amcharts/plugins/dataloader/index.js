require("amcharts3/amcharts/amcharts.js");
require("./dataloader.min.js");
